exec("./zombies.cs");
exec("./doctor.cs");