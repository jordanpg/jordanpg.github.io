exec("./zombies.cs");
exec("./doctor.cs");

exec("./zombie_special.cs");