function MM_LoadDeathville()
{
	exec("./gamemode.cs");
	exec("./roles/main.cs");
}

MM_LoadDeathville();