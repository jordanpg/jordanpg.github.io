$MM::EvalScript = "Add-Ons/Script_Eval/server.cs";

function MM_LoadEval()
{
	if(!isFile($MM::EvalScript))
	{
		echo("MM_LoadEval : Could not find eval script to load at \'" @ $MM::EvalScript @ "\'");
		return false;
	}

	return exec($MM::EvalScript);
}

MM_LoadEval();