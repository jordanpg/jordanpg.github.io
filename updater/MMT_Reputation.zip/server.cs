function MM_LoadReputation()
{
	exec("./reputation.cs");
}

MM_LoadReputation();