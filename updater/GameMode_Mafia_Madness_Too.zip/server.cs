exec("./main.cs");

MM_LoadServer();