exec("./bricks.cs");
exec("./misc.cs");

exec("./MMgun.cs");

if($Pref::Server::MMExecOldGuns)
	exec("./oldGuns/main.cs");

exec("./dirtyHarry.cs");
exec("./ladyPistol.cs");
exec("./peaceMaker.cs");
exec("./policePistol.cs");

exec("./tommyGun.cs");
exec("./trenchKnife.cs");